from datetime import datetime, timedelta
import re

class FinanceHelpers:
    """Utility functions for finance operations"""
    
    @staticmethod
    def validate_email(email):
        """Validate email format"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None
    
    @staticmethod
    def format_currency(amount):
        """Format amount as currency"""
        return f"${amount:,.2f}"
    
    @staticmethod
    def calculate_percentage(part, whole):
        """Calculate percentage"""
        if whole == 0:
            return 0
        return (part / whole) * 100
    
    @staticmethod
    def get_date_range(period):
        """Get start and end dates for a given period"""
        end_date = datetime.now()
        
        if period == 'today':
            start_date = datetime(end_date.year, end_date.month, end_date.day)
        elif period == 'week':
            start_date = end_date - timedelta(days=7)
        elif period == 'month':
            start_date = end_date - timedelta(days=30)
        elif period == 'quarter':
            start_date = end_date - timedelta(days=90)
        elif period == 'year':
            start_date = end_date - timedelta(days=365)
        else:
            start_date = end_date - timedelta(days=30)  # Default to month
        
        return start_date, end_date
    
    @staticmethod
    def categorize_transaction_amount(amount):
        """Categorize transaction by amount"""
        if amount < 10:
            return 'small'
        elif amount < 100:
            return 'medium'
        elif amount < 1000:
            return 'large'
        else:
            return 'very_large'
    
    @staticmethod
    def generate_financial_advice(income, expenses, savings_rate=0.2):
        """Generate basic financial advice"""
        advice = []
        
        net_income = income - expenses
        recommended_savings = income * savings_rate
        
        if net_income <= 0:
            advice.append("⚠️ Your expenses exceed your income. Consider reducing expenses or increasing income.")
        elif net_income < recommended_savings:
            advice.append(f"💡 Try to save at least {FinanceHelpers.format_currency(recommended_savings)} ({savings_rate*100}% of income).")
        else:
            advice.append("✅ Great job! You're maintaining a positive cash flow.")
        
        if expenses > income * 0.8:
            advice.append("💡 Consider the 50/30/20 rule: 50% needs, 30% wants, 20% savings.")
        
        return advice

class DateHelpers:
    """Date utility functions"""
    
    @staticmethod
    def get_month_name(month_number):
        """Get month name from number"""
        months = [
            'January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December'
        ]
        return months[month_number - 1] if 1 <= month_number <= 12 else 'Unknown'
    
    @staticmethod
    def get_quarter(date):
        """Get quarter from date"""
        month = date.month
        if month <= 3:
            return 'Q1'
        elif month <= 6:
            return 'Q2'
        elif month <= 9:
            return 'Q3'
        else:
            return 'Q4'
    
    @staticmethod
    def days_between_dates(start_date, end_date):
        """Calculate days between two dates"""
        return (end_date - start_date).days
