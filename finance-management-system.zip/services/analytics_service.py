from models import db, User, Category, Transaction, Budget
from datetime import datetime, timedelta
from sqlalchemy import func, and_
from collections import defaultdict

class AnalyticsService:
    """Service class for financial analytics and reporting"""
    
    def get_financial_summary(self, user_id, period='monthly'):
        """Get comprehensive financial summary for a user"""
        # Calculate date range based on period
        end_date = datetime.now()
        if period == 'weekly':
            start_date = end_date - timedelta(weeks=1)
        elif period == 'monthly':
            start_date = end_date - timedelta(days=30)
        elif period == 'yearly':
            start_date = end_date - timedelta(days=365)
        else:
            start_date = end_date - timedelta(days=30)  # Default to monthly
        
        # Get transactions for the period
        transactions = Transaction.query.filter(
            and_(
                Transaction.user_id == user_id,
                Transaction.date >= start_date,
                Transaction.date <= end_date
            )
        ).all()
        
        # Calculate totals
        total_income = sum(t.amount for t in transactions if t.type == 'income')
        total_expenses = sum(t.amount for t in transactions if t.type == 'expense')
        net_income = total_income - total_expenses
        
        # Get transaction counts
        income_count = len([t for t in transactions if t.type == 'income'])
        expense_count = len([t for t in transactions if t.type == 'expense'])
        
        # Calculate average transaction amounts
        avg_income = total_income / income_count if income_count > 0 else 0
        avg_expense = total_expenses / expense_count if expense_count > 0 else 0
        
        return {
            'period': period,
            'start_date': start_date.isoformat(),
            'end_date': end_date.isoformat(),
            'total_income': round(total_income, 2),
            'total_expenses': round(total_expenses, 2),
            'net_income': round(net_income, 2),
            'transaction_counts': {
                'income': income_count,
                'expenses': expense_count,
                'total': income_count + expense_count
            },
            'averages': {
                'income': round(avg_income, 2),
                'expense': round(avg_expense, 2)
            }
        }
    
    def get_spending_by_category(self, user_id, period='monthly'):
        """Get spending breakdown by category"""
        # Calculate date range
        end_date = datetime.now()
        if period == 'weekly':
            start_date = end_date - timedelta(weeks=1)
        elif period == 'monthly':
            start_date = end_date - timedelta(days=30)
        elif period == 'yearly':
            start_date = end_date - timedelta(days=365)
        else:
            start_date = end_date - timedelta(days=30)
        
        # Query spending by category
        results = db.session.query(
            Category.name,
            func.sum(Transaction.amount).label('total_amount'),
            func.count(Transaction.id).label('transaction_count')
        ).join(Transaction).filter(
            and_(
                Transaction.user_id == user_id,
                Transaction.type == 'expense',
                Transaction.date >= start_date,
                Transaction.date <= end_date
            )
        ).group_by(Category.name).all()
        
        # Calculate total spending for percentages
        total_spending = sum(result.total_amount for result in results)
        
        # Format results
        category_data = []
        for result in results:
            percentage = (result.total_amount / total_spending * 100) if total_spending > 0 else 0
            category_data.append({
                'category': result.name,
                'amount': round(result.total_amount, 2),
                'transaction_count': result.transaction_count,
                'percentage': round(percentage, 2)
            })
        
        # Sort by amount (highest first)
        category_data.sort(key=lambda x: x['amount'], reverse=True)
        
        return {
            'period': period,
            'total_spending': round(total_spending, 2),
            'categories': category_data
        }
    
    def get_monthly_trend(self, user_id, months=6):
        """Get monthly income and expense trends"""
        end_date = datetime.now()
        start_date = end_date - timedelta(days=months * 30)
        
        # Get all transactions in the period
        transactions = Transaction.query.filter(
            and_(
                Transaction.user_id == user_id,
                Transaction.date >= start_date,
                Transaction.date <= end_date
            )
        ).all()
        
        # Group by month
        monthly_data = defaultdict(lambda: {'income': 0, 'expenses': 0})
        
        for transaction in transactions:
            month_key = transaction.date.strftime('%Y-%m')
            if transaction.type == 'income':
                monthly_data[month_key]['income'] += transaction.amount
            else:
                monthly_data[month_key]['expenses'] += transaction.amount
        
        # Format results
        trend_data = []
        for month_key in sorted(monthly_data.keys()):
            data = monthly_data[month_key]
            trend_data.append({
                'month': month_key,
                'income': round(data['income'], 2),
                'expenses': round(data['expenses'], 2),
                'net': round(data['income'] - data['expenses'], 2)
            })
        
        return {
            'months': months,
            'data': trend_data
        }
    
    def get_budget_status(self, user_id):
        """Get budget status and alerts"""
        # Get current month's start and end dates
        now = datetime.now()
        start_of_month = datetime(now.year, now.month, 1)
        if now.month == 12:
            end_of_month = datetime(now.year + 1, 1, 1) - timedelta(days=1)
        else:
            end_of_month = datetime(now.year, now.month + 1, 1) - timedelta(days=1)
        
        # Get user's budgets
        budgets = Budget.query.filter_by(user_id=user_id).all()
        
        budget_status = []
        alerts = []
        
        for budget in budgets:
            # Calculate spent amount for this category in current month
            spent = db.session.query(func.sum(Transaction.amount)).filter(
                and_(
                    Transaction.user_id == user_id,
                    Transaction.category_id == budget.category_id,
                    Transaction.type == 'expense',
                    Transaction.date >= start_of_month,
                    Transaction.date <= end_of_month
                )
            ).scalar() or 0
            
            # Calculate percentage used
            percentage_used = (spent / budget.amount * 100) if budget.amount > 0 else 0
            remaining = budget.amount - spent
            
            status = {
                'budget_id': budget.id,
                'category': budget.category.name,
                'budget_amount': budget.amount,
                'spent_amount': round(spent, 2),
                'remaining_amount': round(remaining, 2),
                'percentage_used': round(percentage_used, 2),
                'status': 'over_budget' if spent > budget.amount else 'on_track'
            }
            
            budget_status.append(status)
            
            # Generate alerts
            if percentage_used >= 100:
                alerts.append({
                    'type': 'over_budget',
                    'category': budget.category.name,
                    'message': f'You have exceeded your budget for {budget.category.name} by ${round(spent - budget.amount, 2)}'
                })
            elif percentage_used >= 80:
                alerts.append({
                    'type': 'warning',
                    'category': budget.category.name,
                    'message': f'You have used {round(percentage_used, 1)}% of your budget for {budget.category.name}'
                })
        
        return {
            'period': f'{start_of_month.strftime("%Y-%m")}',
            'budget_status': budget_status,
            'alerts': alerts,
            'total_budgets': len(budgets)
        }
    
    def get_expense_trends(self, user_id, days=30):
        """Get daily expense trends"""
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        # Get daily expenses
        daily_expenses = db.session.query(
            func.date(Transaction.date).label('date'),
            func.sum(Transaction.amount).label('total_amount')
        ).filter(
            and_(
                Transaction.user_id == user_id,
                Transaction.type == 'expense',
                Transaction.date >= start_date,
                Transaction.date <= end_date
            )
        ).group_by(func.date(Transaction.date)).all()
        
        # Format results
        trend_data = []
        for expense in daily_expenses:
            trend_data.append({
                'date': expense.date.isoformat(),
                'amount': round(expense.total_amount, 2)
            })
        
        # Sort by date
        trend_data.sort(key=lambda x: x['date'])
        
        return {
            'days': days,
            'data': trend_data
        }
