from models import db, User, Category, Transaction, Budget
from datetime import datetime
from sqlalchemy import and_, or_

class FinanceService:
    """Service class for handling finance-related operations"""
    
    def create_user(self, name, email):
        """Create a new user"""
        # Check if user already exists
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            raise ValueError("User with this email already exists")
        
        user = User(name=name, email=email)
        db.session.add(user)
        db.session.commit()
        return user
    
    def create_category(self, name):
        """Create a new category"""
        # Check if category already exists
        existing_category = Category.query.filter_by(name=name).first()
        if existing_category:
            raise ValueError("Category with this name already exists")
        
        category = Category(name=name)
        db.session.add(category)
        db.session.commit()
        return category
    
    def create_transaction(self, user_id, category_id, amount, description, transaction_type, date=None):
        """Create a new transaction"""
        # Validate user exists
        user = User.query.get(user_id)
        if not user:
            raise ValueError("User not found")
        
        # Validate category exists
        category = Category.query.get(category_id)
        if not category:
            raise ValueError("Category not found")
        
        # Validate transaction type
        if transaction_type not in ['income', 'expense']:
            raise ValueError("Transaction type must be 'income' or 'expense'")
        
        # Validate amount
        if amount <= 0:
            raise ValueError("Amount must be greater than 0")
        
        transaction = Transaction(
            user_id=user_id,
            category_id=category_id,
            amount=amount,
            description=description,
            transaction_type=transaction_type,
            date=date
        )
        
        db.session.add(transaction)
        db.session.commit()
        return transaction
    
    def get_transactions(self, user_id=None, category_id=None, transaction_type=None, start_date=None, end_date=None):
        """Get transactions with optional filters"""
        query = Transaction.query
        
        if user_id:
            query = query.filter(Transaction.user_id == user_id)
        
        if category_id:
            query = query.filter(Transaction.category_id == category_id)
        
        if transaction_type:
            query = query.filter(Transaction.type == transaction_type)
        
        if start_date:
            start_date = datetime.fromisoformat(start_date)
            query = query.filter(Transaction.date >= start_date)
        
        if end_date:
            end_date = datetime.fromisoformat(end_date)
            query = query.filter(Transaction.date <= end_date)
        
        return query.order_by(Transaction.date.desc()).all()
    
    def update_transaction(self, transaction_id, data):
        """Update a transaction"""
        transaction = Transaction.query.get(transaction_id)
        if not transaction:
            raise ValueError("Transaction not found")
        
        # Update fields if provided
        if 'amount' in data:
            if data['amount'] <= 0:
                raise ValueError("Amount must be greater than 0")
            transaction.amount = data['amount']
        
        if 'description' in data:
            transaction.description = data['description']
        
        if 'category_id' in data:
            category = Category.query.get(data['category_id'])
            if not category:
                raise ValueError("Category not found")
            transaction.category_id = data['category_id']
        
        if 'type' in data:
            if data['type'] not in ['income', 'expense']:
                raise ValueError("Transaction type must be 'income' or 'expense'")
            transaction.type = data['type']
        
        if 'date' in data:
            transaction.date = datetime.fromisoformat(data['date'])
        
        db.session.commit()
        return transaction
    
    def delete_transaction(self, transaction_id):
        """Delete a transaction"""
        transaction = Transaction.query.get(transaction_id)
        if not transaction:
            raise ValueError("Transaction not found")
        
        db.session.delete(transaction)
        db.session.commit()
    
    def create_budget(self, user_id, category_id, amount, period='monthly'):
        """Create a new budget"""
        # Validate user exists
        user = User.query.get(user_id)
        if not user:
            raise ValueError("User not found")
        
        # Validate category exists
        category = Category.query.get(category_id)
        if not category:
            raise ValueError("Category not found")
        
        # Validate amount
        if amount <= 0:
            raise ValueError("Budget amount must be greater than 0")
        
        # Check if budget already exists for this user and category
        existing_budget = Budget.query.filter_by(user_id=user_id, category_id=category_id).first()
        if existing_budget:
            raise ValueError("Budget already exists for this category")
        
        budget = Budget(
            user_id=user_id,
            category_id=category_id,
            amount=amount,
            period=period
        )
        
        db.session.add(budget)
        db.session.commit()
        return budget
    
    def get_budgets(self, user_id):
        """Get budgets for a user"""
        return Budget.query.filter_by(user_id=user_id).all()
    
    def update_budget(self, budget_id, data):
        """Update a budget"""
        budget = Budget.query.get(budget_id)
        if not budget:
            raise ValueError("Budget not found")
        
        if 'amount' in data:
            if data['amount'] <= 0:
                raise ValueError("Budget amount must be greater than 0")
            budget.amount = data['amount']
        
        if 'period' in data:
            budget.period = data['period']
        
        db.session.commit()
        return budget
    
    def delete_budget(self, budget_id):
        """Delete a budget"""
        budget = Budget.query.get(budget_id)
        if not budget:
            raise ValueError("Budget not found")
        
        db.session.delete(budget)
        db.session.commit()
    
    def calculate_balance(self, user_id, start_date=None, end_date=None):
        """Calculate user's balance (income - expenses)"""
        query = Transaction.query.filter_by(user_id=user_id)
        
        if start_date:
            query = query.filter(Transaction.date >= datetime.fromisoformat(start_date))
        
        if end_date:
            query = query.filter(Transaction.date <= datetime.fromisoformat(end_date))
        
        transactions = query.all()
        
        total_income = sum(t.amount for t in transactions if t.type == 'income')
        total_expenses = sum(t.amount for t in transactions if t.type == 'expense')
        
        return {
            'total_income': total_income,
            'total_expenses': total_expenses,
            'balance': total_income - total_expenses
        }
