from app import app
from models import db, User, Category, Transaction, Budget
from datetime import datetime, timedelta
import random

def seed_database():
    """Seed the database with sample data"""
    with app.app_context():
        # Clear existing data
        db.drop_all()
        db.create_all()
        
        print("Creating categories...")
        # Create categories
        categories_data = [
            'Food & Dining', 'Transportation', 'Shopping', 'Entertainment',
            'Bills & Utilities', 'Healthcare', 'Education', 'Travel',
            'Salary', 'Freelance', 'Investment', 'Other'
        ]
        
        categories = []
        for cat_name in categories_data:
            category = Category(name=cat_name)
            db.session.add(category)
            categories.append(category)
        
        db.session.commit()
        print(f"Created {len(categories)} categories")
        
        print("Creating users...")
        # Create sample users
        users_data = [
            {'name': 'John Doe', 'email': 'john.doe@example.com'},
            {'name': 'Jane Smith', 'email': 'jane.smith@example.com'},
            {'name': 'Mike Johnson', 'email': 'mike.johnson@example.com'}
        ]
        
        users = []
        for user_data in users_data:
            user = User(name=user_data['name'], email=user_data['email'])
            db.session.add(user)
            users.append(user)
        
        db.session.commit()
        print(f"Created {len(users)} users")
        
        print("Creating transactions...")
        # Create sample transactions
        expense_categories = [cat for cat in categories if cat.name not in ['Salary', 'Freelance', 'Investment']]
        income_categories = [cat for cat in categories if cat.name in ['Salary', 'Freelance', 'Investment']]
        
        transactions = []
        for user in users:
            # Create income transactions
            for i in range(5):  # 5 income transactions per user
                category = random.choice(income_categories)
                amount = random.uniform(1000, 5000)
                date = datetime.now() - timedelta(days=random.randint(1, 90))
                
                transaction = Transaction(
                    user_id=user.id,
                    category_id=category.id,
                    amount=round(amount, 2),
                    description=f"Income from {category.name}",
                    transaction_type='income',
                    date=date
                )
                transactions.append(transaction)
                db.session.add(transaction)
            
            # Create expense transactions
            for i in range(20):  # 20 expense transactions per user
                category = random.choice(expense_categories)
                amount = random.uniform(10, 500)
                date = datetime.now() - timedelta(days=random.randint(1, 90))
                
                descriptions = {
                    'Food & Dining': ['Restaurant dinner', 'Grocery shopping', 'Coffee shop', 'Fast food'],
                    'Transportation': ['Gas station', 'Uber ride', 'Bus ticket', 'Car maintenance'],
                    'Shopping': ['Clothing store', 'Electronics', 'Home goods', 'Online purchase'],
                    'Entertainment': ['Movie tickets', 'Concert', 'Streaming service', 'Games'],
                    'Bills & Utilities': ['Electric bill', 'Internet bill', 'Phone bill', 'Water bill'],
                    'Healthcare': ['Doctor visit', 'Pharmacy', 'Dental checkup', 'Insurance'],
                    'Education': ['Course fee', 'Books', 'Online learning', 'Workshop'],
                    'Travel': ['Flight ticket', 'Hotel booking', 'Car rental', 'Travel insurance']
                }
                
                description = random.choice(descriptions.get(category.name, ['Expense']))
                
                transaction = Transaction(
                    user_id=user.id,
                    category_id=category.id,
                    amount=round(amount, 2),
                    description=description,
                    transaction_type='expense',
                    date=date
                )
                transactions.append(transaction)
                db.session.add(transaction)
        
        db.session.commit()
        print(f"Created {len(transactions)} transactions")
        
        print("Creating budgets...")
        # Create sample budgets
        budgets = []
        for user in users:
            # Create budgets for some expense categories
            budget_categories = random.sample(expense_categories, 5)  # 5 budgets per user
            
            for category in budget_categories:
                amount = random.uniform(200, 1000)
                budget = Budget(
                    user_id=user.id,
                    category_id=category.id,
                    amount=round(amount, 2),
                    period='monthly'
                )
                budgets.append(budget)
                db.session.add(budget)
        
        db.session.commit()
        print(f"Created {len(budgets)} budgets")
        
        print("Database seeded successfully!")
        print(f"Total records created:")
        print(f"- Users: {len(users)}")
        print(f"- Categories: {len(categories)}")
        print(f"- Transactions: {len(transactions)}")
        print(f"- Budgets: {len(budgets)}")

if __name__ == '__main__':
    seed_database()
